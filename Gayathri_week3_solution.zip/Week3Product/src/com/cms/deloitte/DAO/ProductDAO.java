package com.cms.deloitte.DAO;

import java.util.List;

import com.cms.deloitte.model.Product;

public interface ProductDAO {
	public void updateProduct(Product product);
	public List<Product> diplayproduct();

}
