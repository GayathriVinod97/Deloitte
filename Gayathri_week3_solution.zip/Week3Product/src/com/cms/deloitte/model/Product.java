package com.cms.deloitte.model;

public class Product {
	
	private String productId,productName,qoh,price;
	public Product() {
		
	}
	
	public Product(String productId2, String productName, String qoh2, String price2) {
		super();
		this.productId = productId2;
		this.productName = productName;
		this.qoh = qoh2;
		this.price = price2;
	}
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getQoh() {
		return qoh;
	}
	public void setQoh(String qoh) {
		this.qoh = qoh;
	}
	public String getPrice() {
		return price;
	}
	public void setPrice(String price) {
		this.price = price;
	}
	@Override
	public String toString() {
		return "Product [productId=" + productId + ", productName=" + productName + ", qoh=" + qoh + ", price=" + price
				+ "]";
	}
	
	

}
