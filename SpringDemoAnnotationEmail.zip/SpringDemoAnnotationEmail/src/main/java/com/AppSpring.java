package com;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import com.config.AppConfig;

public class AppSpring {

	public static void main(String[] args) {
		ApplicationContext context= new AnnotationConfigApplicationContext(AppConfig.class);
		
	
		
		Customer customer= context.getBean(Customer.class);
		
		ToEmail toEmail=context.getBean(ToEmail.class);
		toEmail.setToName("Gayathri");
		toEmail.setToEmail("J@gmail.com");
		customer.setToEmail(toEmail);
		
		FromEmail fromEmail=context.getBean(FromEmail.class);
		fromEmail.setFromEmail("x.gmail");
		fromEmail.setFromName("xyz");
		customer.setFromEmail(fromEmail);
		
		Subject subject=context.getBean(Subject.class);
		subject.setCaption("Hello");
		customer.setSubject(subject);
		
		customer.setSubject(subject);
		Body body=context.getBean(Body.class);
		body.setMessage("helloo");
		
		
		customer.setBody(body);
		
		
	
		System.out.println(customer);

	}

}
