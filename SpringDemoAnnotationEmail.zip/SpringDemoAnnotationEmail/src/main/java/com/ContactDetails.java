package com;

public class ContactDetails {
	private String mobileNumber;
	private String mailId;
	
	public ContactDetails(String mobileNumber, String mailId) {
		super();
		this.mobileNumber = mobileNumber;
		this.mailId = mailId;
	}
	public ContactDetails() {
	}
	public String getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public String getMailId() {
		return mailId;
	}
	public void setMailId(String mailId) {
		this.mailId = mailId;
	}
	@Override
	public String toString() {
		return "ContactDetails [mobileNumber=" + mobileNumber + ", mailId=" + mailId + "]";
	}
	
	

}
