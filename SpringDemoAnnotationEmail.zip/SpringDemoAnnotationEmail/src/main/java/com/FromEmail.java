package com;

public class FromEmail {
	private String fromName;
	private String fromEmail;
	public FromEmail(String fromName, String fromEmail) {
		super();
		this.fromName = fromName;
		this.fromEmail = fromEmail;
	}
	
	public FromEmail() {
		
	}

	public String getFromName() {
		return fromName;
	}

	public void setFromName(String fromName) {
		this.fromName = fromName;
	}

	public String getFromEmail() {
		return fromEmail;
	}

	public void setFromEmail(String fromEmail) {
		this.fromEmail = fromEmail;
	}

	@Override
	public String toString() {
		return "FromEmail [fromName=" + fromName + ", fromEmail=" + fromEmail + "]";
	}
	
}
