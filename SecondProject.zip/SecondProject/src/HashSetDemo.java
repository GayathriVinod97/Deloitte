import java.util.LinkedHashSet;
import java.util.List;

public class HashSetDemo {
	public static void main(String[] args) {
		LinkedHashSet names= new LinkedHashSet();
		names.add("Jay");
		names.add("Ray");
		names.add("May");
		names.add("Say");
		System.out.println(names);
		
	}

}
