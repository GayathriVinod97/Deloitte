
public class ObjectDemo {
	public static void main(String[] args) {
		
	
	Customer customer= new Customer("C001","Gayathri", "Kerala", 10000);
	System.out.println(customer);
	customer.setBillAmount(2000);
	System.out.println(customer);
	}

}
