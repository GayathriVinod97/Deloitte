import java.util.Scanner;

class InvalidAgeException extends Exception{
	public InvalidAgeException() {
		
	}
	public InvalidAgeException(String msg) {
		super(msg);
	}
	
}
class NewYearParty{
	int eligibleAge=16;
	Scanner scanner= new Scanner(System.in);
	int age;
	public void enterClub() throws InvalidAgeException{
		System.out.println("Please enter age :");
		age= scanner.nextInt();
		if(age<eligibleAge) {
			throw new InvalidAgeException("UnderAge");
		}
		else {
			System.out.println("Welcome");
		}
		System.out.println("hello");
	}
}
public class Demo5 {
	public static void main(String[] args) throws InvalidAgeException{
		
	
	
	NewYearParty p= new NewYearParty();
	
	try {
		p.enterClub();
	} catch (InvalidAgeException e) {
		
		e.printStackTrace();
	}
	System.out.println("enjoy");
	
}
}
