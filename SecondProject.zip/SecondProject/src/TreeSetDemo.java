import java.util.TreeSet;
public class TreeSetDemo {

	public static void main(String[] args) {
		TreeSet names= new TreeSet();
		names.add("Ga");
		names.add("Za");
		names.add("Aa");
		System.out.println(names);

	}

}
