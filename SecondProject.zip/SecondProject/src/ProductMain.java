
public class ProductMain {
	public static void main(String[] args) {
		ProductDetails prod1= new ProductDetails("P001","Laptop" ,20 , 65000);
		ProductDetails prod2= new ProductDetails("P002","Mouse" ,15 , 2000);
		ProductDetails prod3= new ProductDetails("P003","Speaker" ,10 ,5000);
		ProductDetails prod4= new ProductDetails("P001","Laptop" ,20 , 65000);
		System.out.println(prod1);
		System.out.println(prod2);
		System.out.println(prod3);
		System.out.println(prod1.equals(prod4));
		
		
	}

}
