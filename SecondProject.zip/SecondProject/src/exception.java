
public class exception {
	public void display1()throws Exception {
		System.out.println("Welcome in diplay");
		Thread.sleep(1000);
		System.out.println("bye");
		
	}
	public void display2()throws InterruptedException {
		System.out.println("Welcome in diplay");
		Thread.sleep(1000);
		System.out.println("bye");
		
	}
	public static void main(String[] args)throws Exception {
		System.out.println("main started");
		exception e= new exception();
		e.display1();
		e.display2();
		System.out.println("main ended");
		
	}

}
