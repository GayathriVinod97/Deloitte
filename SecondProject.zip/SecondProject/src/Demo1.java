import java.util.InputMismatchException;
import java.util.Scanner;

public class Demo1 {
	int num1, num2;
	int result;
	Scanner scanner= new Scanner(System.in);
	public void display() {
		System.out.println("Welcome to display");
		try {
			System.out.println("Enter first no");
			num1 = scanner.nextInt();
			System.out.println("Enter Second no");
			num2 = scanner.nextInt();
			result = num1 / num2;
			System.out.println(result);
		} catch (InputMismatchException  e) {
			System.out.println("Enter only a number");
		}
		catch(ArithmeticException e) {
			System.out.println("Dont enter 0 as second number");
		}
		System.out.println("bye");
		
	}
	public static void main( String[] args) {
		System.out.println("in main");
		Demo1 d= new Demo1();
		d.display();
		System.out.println("the end");
	}
	

}
