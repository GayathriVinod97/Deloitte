package com;

import java.io.Serializable;
import java.util.Scanner;

import org.springframework.beans.factory.annotation.Autowired;

public class Email implements Serializable {
	public Email() {
		
	}
	@Autowired
	ToEmail toEmail;
	public ToEmail getTo() {
		return toEmail;
		
	}
	@Autowired
	FromEmail fromEmail;
	public FromEmail getFrom() {
		return fromEmail;
		
	}
	@Autowired(required=false)
	Subject subject;
	
	public Subject getSubject() {
		return subject;
		
	}
	@Autowired(required=false)
	Body body;
	public Body getBody() {
		return body;
		
	}
	public ToEmail getToEmail() {
		return toEmail;
	}
	public void setToEmail(ToEmail toEmail) {
		this.toEmail = toEmail;
	}
	public FromEmail getFromEmail() {
		return fromEmail;
	}
	public void setFromEmail(FromEmail fromEmail) {
		this.fromEmail = fromEmail;
	}
	public void setSubject(Subject subject) {
		this.subject = subject;
	}
	public void setBody(Body body) {
		this.body = body;
	}
	public Email(ToEmail toEmail, FromEmail fromEmail, Subject subject, Body body) {
		super();
		this.toEmail = toEmail;
		this.fromEmail = fromEmail;
		this.subject = subject;
		this.body = body;
	}
	@Override
	public String toString() {
		return "Customer [toEmail=" + toEmail + ", fromEmail=" + fromEmail + ", subject=" + subject + ", body=" + body
				+ "]";
	}
	
	
	
}
	