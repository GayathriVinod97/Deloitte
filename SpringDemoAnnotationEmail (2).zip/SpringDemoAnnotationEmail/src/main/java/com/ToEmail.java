package com;

public class ToEmail {
	private String toName;
	private String toEmail;
	public String getToName() {
		return toName;
	}
	public void setToName(String toName) {
		this.toName = toName;
	}
	public String getToEmail() {
		return toEmail;
	}
	public void setToEmail(String toEmail) {
		this.toEmail = toEmail;
	}
	public ToEmail(String toName, String toEmail) {
		super();
		this.toName = toName;
		this.toEmail = toEmail;
	}
	public ToEmail() {
		
	}
	@Override
	public String toString() {
		return "ToEmail [toName=" + toName + ", toEmail=" + toEmail + "]";
	}
	

}
