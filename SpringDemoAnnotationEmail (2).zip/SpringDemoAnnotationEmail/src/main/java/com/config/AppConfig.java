package com.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.Body;
import com.ContactDetails;
import com.Email;
import com.FromEmail;
import com.Subject;
import com.ToEmail;
@Configuration
public class AppConfig {
	@Bean
	public Email getCustomer() {
		return new Email();
	}
	@Bean
	public ToEmail getTo() {
		return new ToEmail();
	}
	@Bean
	public FromEmail getFrom() {
		return new FromEmail();
	}
	@Bean
	public Subject getSubject() {
		return new Subject();
	}
	@Bean
	public Body getBody() {
		return new Body();
	}
	
	
	
	

}
