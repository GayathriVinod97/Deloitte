package com.pms.deloitte.controller;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.pms.deloitte.model.Product;

@SpringBootApplication
@Controller

public class ProductController {
	@RequestMapping("/product")
	public ModelAndView saveProduct() {
		ModelAndView view= new ModelAndView();
		view.addObject("command", new Product());
		view.setViewName("product");
		return view;
	}
	@RequestMapping("/saveProduct")
	public ModelAndView Productform(Product product) {
		ModelAndView view= new ModelAndView("product");
		view.addObject("command", new Product());
		System.out.println(product);
		return view;
	}
	@RequestMapping("/updateProduct")
	public ModelAndView updateProduct() {
		ModelAndView view= new ModelAndView("updateproduct");
		return view;
	}
	@RequestMapping("/deleteProduct")
	public ModelAndView deleteProduct() {
		ModelAndView view= new ModelAndView("deleteproduct");
		return view;
	}
	
	

}
