package oops;

import java.util.Scanner;

public class Employee {
	public int employeeId;
	public String employeeName;
	public String employeeAddress;
	public int salary;
	
	public void takeSalary() {
		Scanner sc= new Scanner(System.in);
		System.out.println("enter employeeid");
		employeeId= sc.nextInt();
		System.out.println("enter empname");
		employeeName= sc.next();

		System.out.println("enter empAddress");
		employeeAddress= sc.next();
        System.out.println("enter empsalary");
		
		salary= sc.nextInt();
		sc.close();
		
		
		
	}
	public void printEmployeeDetails() {
		System.out.println("Employee id :"+employeeId);
		System.out.println("Employee name :"+employeeName);
		System.out.println("Employee address :"+employeeAddress);
		System.out.println("Employee salary :"+salary);
	}

}
