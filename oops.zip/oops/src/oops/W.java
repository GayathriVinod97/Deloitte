package oops;

public class W {
	public W() {
		System.out.println("in W constructor");
	}

}
