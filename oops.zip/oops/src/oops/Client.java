package oops;



public class Client {
	public static void main(String [] args) {
		Employee employee= new Employee();
		employee.takeSalary();
		employee.printEmployeeDetails();
		Customer c1= new Customer();
		c1.display();
		Customer c2= new Customer();
		c2.setBillAmount(2000);
		c2.display();
		
		}
	}


