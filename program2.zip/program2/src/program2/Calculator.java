package program2;



public class Calculator {
	
	public void add(int num1, int num2) {
		System.out.println("in method1 : "+ (num1+num2));
	}
	public void add(double num1, double num2) {
		System.out.println("in method2 : "+ num1+num2);
	}
	public void add(int num1, double num2) {
		System.out.println("in method3 : "+num1+num2);
	}
	public void add(double num1, int num2) {
		System.out.println("in method4 : "+num1+num2);
	}
	public void diff(int num1, int num2) {
		System.out.println("in method1 : "+ (num1-num2));
	}
	public void diff(double num1, double num2) {
		System.out.println("in method2 : "+(num1-num2));
	}
	public void diff(int num1, double num2) {
		System.out.println("in method3 : "+(num1-num2));
	}
	public void diff(double num1, int num2) {
		System.out.println("in method4 : "+(num1-num2));
	}
	public void mul(int num1, int num2) {
		System.out.println("in method1 : "+num1*num2);
	}
	public void mul(double num1, double num2) {
		System.out.println("in method2 : "+num1*num2);
	}
	public void mul(int num1, double num2) {
		System.out.println("in method3 : "+num1*num2);
	}
	public void mul(double num1, int num2) {
		System.out.println("in method4 : "+num1*num2);
	}
	public void div(int num1, int num2) {
		System.out.println("in method1 : "+num1/num2);
	}
	public void div(double num1, double num2) {
		System.out.println("in method2 : "+num1/num2);
	}
	public void div(int num1, double num2) {
		System.out.println("in method3 : "+num1/num2);
	}
	public void div(double num1, int num2) {
		System.out.println("in method4 : "+num1/num2);
	}
	

	public static void main(String[] args) {
		
		Calculator calculator= new Calculator();
		calculator.add(6,2);
		calculator.diff(6,2);
		calculator.mul(6,2);
		calculator.div(6, 2);
		calculator.add(2.5,2.5);
		calculator.diff(2.5,2.5);
		calculator.mul(2.5,2.5);
		calculator.div(2.5,2.5);
		calculator.add(3,1.7);
		calculator.diff(3,1.7);
		calculator.mul(3,1.7);
		calculator.div(3,1.7);
		calculator.add(6.5,2);
		calculator.diff(6.5,2);
		calculator.mul(6.5,2);
		calculator.div(6.5,2);
		
		
		
		
		

	}

}
