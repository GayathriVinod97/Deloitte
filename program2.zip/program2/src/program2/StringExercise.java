package program2;

import java.util.StringTokenizer;

public class StringExercise {
	
	
	

	public static void main(String[] args) {
		String str1= "The quick brown fox jumps over the lazy dog";
		System.out.println(str1.charAt(12));
		System.out.println("-----------------------------------");
		if(str1.contains("is")) {
			System.out.println("String contains the word is");
		}
		else {
			System.out.println("String doesnt contain the word is");
		}
		System.out.println("-----------------------------------");
		String strnew= str1.concat(" and killed it");
		System.out.println("New string is : "+ strnew);
		System.out.println("-----------------------------------");
		String lastWord=str1.substring(str1.lastIndexOf(" ")+1);
		if(lastWord.equals("dogs")) {
			System.out.println("Last word is dogs");
		}
		else {
			System.out.println("Last word is not dogs");
		}
		System.out.println("-----------------------------------");
		String str2 = "The quick brown Fox jumps over the lazy Dog";
		if(str2.equals(str1)) {
			System.out.println("The 2 strings are equal");
		}
		else {
			System.out.println("The 2 strings are not equal");
		}
		System.out.println("-----------------------------------");
		str2="THE QUICK BROWN FOX JUMPS OVER THE LAZY DOG";
		if(str2.equals(str1)) {
			System.out.println("The 2 strings are equal");
		}
		else {
			System.out.println("The 2 strings are not equal");
		}
		System.out.println("-----------------------------------");
		System.out.println(str1.length());
		System.out.println("-----------------------------------");
		System.out.println((str1.matches("The quick brown Fox jumps over the lazy Dog")));
		System.out.println("-----------------------------------");
		str1= str1.replace("The", "A");
		System.out.println(str1);
		System.out.println("-----------------------------------");
		System.out.println(str1.substring(0, 32));
		System.out.println(str1.substring(33, 41));
		System.out.println("-----------------------------------");
		
		String[] words= str1.split(" ");
		for (String word: words) {
			if((word.equals("fox"))||(word.equals("dog"))){
					System.out.println(word);}
		}
		
		
		System.out.println(str1.toLowerCase());
		System.out.println("-----------------------------------");
		System.out.println(str1.toUpperCase());
		System.out.println("-----------------------------------");
		System.out.println(str1.indexOf('a'));
		System.out.println("-----------------------------------");
		System.out.println(str1.lastIndexOf("e"));
		
		
		//String newString= String.join(" ", words);
		//System.out.println(newString);
		
		
		
		
	}

}
