package program2;



public class Client {
	public static void main(String [] args) {
		Employee employee= new Employee();
		employee.takeSalary();
		employee.printEmployeeDetails();
		
		}
	}


