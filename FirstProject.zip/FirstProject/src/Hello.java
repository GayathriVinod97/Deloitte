
public class Hello {
	public void sayHello() {
		System.out.println("Hello");
		
	}

}
