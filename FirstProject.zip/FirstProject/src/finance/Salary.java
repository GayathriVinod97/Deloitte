 package finance;

public class Salary {
	public int calcSalary(int b,int p) {
		return b+p;
		
	}

}
