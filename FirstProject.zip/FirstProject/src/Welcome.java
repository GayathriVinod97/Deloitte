import finance.Salary;
public class Welcome {

	public static void main(String[] args) {
		System.out.println("welcome");
		Thanks t= new Thanks();
		t.sayThanks();
		Bye b= new Bye();
		b.sayBye();
		Hello h = new Hello();
		h.sayHello();
		Hi i= new Hi();
		i.sayHi();
		Salary s= new Salary();
		int r= s.calcSalary(2,3);
		System.out.println(r);
		
		
		
	}

}
