

public class Demo {
	
	int i;
	int num= 10;
	public void display() {
		int j=20;// or leave as int j and initialise j in an else.instace var i automatically initialised but not local var j.
		if(num==10) {
			j=20;
		}
		System.out.println((i+num)-j);
	}

	public static void main(String[] args) {
		Demo d= new Demo();
		d.display();

	}

}
