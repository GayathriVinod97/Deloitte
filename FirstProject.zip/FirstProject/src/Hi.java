
public class Hi {
	public void sayHi() {
		System.out.println("Hi");
	}

}
