package pack1;

public class B extends A{
	public void display() {
		A a= new A();
		a.i=2;
		i=200;
				
	}
	

}
