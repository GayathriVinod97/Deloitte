package com.customtag;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.TagSupport;

public class AddressTags extends TagSupport {

	@Override
	public int doStartTag() throws JspException {
		
		JspWriter out= pageContext.getOut();
		
		try {
			out.println("Deloitte<br/>");
			out.println("Block C<br/> Divyasree Technopolis<br/>");
			out.println("Survey no: ");
			out.println("Yemlur ");
			out.println("Karnataka");
			}
		catch(Exception e){
			e.printStackTrace();
			
		}
		return super.doStartTag();
	}
	
	
 
	
}
