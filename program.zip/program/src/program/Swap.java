package program;

import java.util.Scanner;

public class Swap {
	public void swapValue(int num1, int num2) {
		num1=num1+num2;
		num2=num1-num2;
		num1=num1-num2;
		
		System.out.println(num1);
		System.out.println(num2);
		
		
		
	}

	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		if(sc.hasNextInt()) {
			int num1=sc.nextInt();
			int num2= sc.nextInt();
			Swap swap= new Swap();
			swap.swapValue(num1,num2);
		}
		sc.close();

	}

}
