package program;

import java.util.Scanner;

public class Swap {
	public void swapValue(int a, int b) {
		a=a+b;
		b=a-b;
		a=a-b;
		
		System.out.println(a);
		System.out.println(b);
		
		
		
	}

	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		if(sc.hasNextInt()) {
			int num1=sc.nextInt();
			int num2= sc.nextInt();
			Swap swap= new Swap();
			swap.swapValue(num1,num2);
		}

	}

}
