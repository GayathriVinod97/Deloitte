package com;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.exam.Controller.HttpSession;
import com.exam.Controller.RequestDispatcher;

/**
 * Servlet implementation class InstructionServlet
 */
public class InstructionServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
    public InstructionServlet() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String Name = request.getParameter("Name");
		HttpSession session = request.getSession();
		session.setAttribute("Name",Name);
		
		RequestDispatcher dispatcher = request.getRequestDispatcher("Instruction.html");
		dispatcher.forward(request, response);
	}

}
