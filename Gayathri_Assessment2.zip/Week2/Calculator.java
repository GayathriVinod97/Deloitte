package Week2;

import java.util.Scanner;

public class Calculator {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter choice 1.Addition  2.Subtraction  3. Multiplication   4. Division");
		int choice= scanner.nextInt();
		System.out.println("enter 1st number");
		int num1= scanner.nextInt();
		System.out.println("enter 2nd number");
		int num2= scanner.nextInt();
		Arithmetic [] operation = {new Addition(num1,num2),new Subtraction(num1,num2),new Multiplication(num1,num2),new Division(num1, num2)};
		double result =operation[choice-1].calculate(num1, num2);
		System.out.println(result);
			

	}

}
