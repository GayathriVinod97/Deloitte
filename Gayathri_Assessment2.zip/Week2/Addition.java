package Week2;

public class Addition extends Arithmetic {

	public Addition(int num1, int num2) {
		super(num1, num2);
		
	}

	@Override
	public double calculate(int num1, int num2) {
		double num3= num1+num2;
		return num3;
	}

	
	

}
