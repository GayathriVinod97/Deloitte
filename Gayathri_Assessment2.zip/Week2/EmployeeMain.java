package Week2;

import java.util.Collections;
import java.util.Scanner;

public class EmployeeMain {

	public static void main(String[] args) {
		Scanner scanner= new Scanner(System.in);
		System.out.println("Enter number of customers");
		int num= scanner.nextInt();
		EmployeeVo employeeVo []= new EmployeeVo[num];
		while(num!=0) {
		System.out.println("Enter Employee id");
		int empId= scanner.nextInt();
		System.out.println("Enter Employee Name");
		String empname= scanner.next();
		System.out.println("Enter Annual income");
		int income= scanner.nextInt();
		int i=0;
		employeeVo[i].setEmpid(empId);
		employeeVo[i].setEmpname(empname);
		employeeVo[i].setAnnualincome(income);
		EmployeeBo employeeBo= new EmployeeBo();
		employeeBo.calincomeTax(employeeVo[i]);
		
		
		
		i++;
		num--;
		}
		System.out.println("\n Employee details\n");
		while(num!=0) {
			int i=0;
			System.out.println(employeeVo[i]);
			i++;
			num--;
			
		}
	//	Emplyeesort sort= new Emplyeesort();
	//	sort.compare(o1, o2)
//
	}

}
