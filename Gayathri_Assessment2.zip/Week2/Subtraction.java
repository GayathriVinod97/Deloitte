package Week2;

public class Subtraction extends Arithmetic {

	public Subtraction(int num1, int num2) {
		super(num1, num2);
		
	}

	@Override
	public double calculate(int num1,int num2) {
		double num3= num1-num2;
		return num3;
		
		
	}
	
	

}
