package Week2;

import java.util.Comparator;

public class Emplyeesort implements Comparator<EmployeeVo>{

	@Override
	public int compare(EmployeeVo o1, EmployeeVo o2) {
		if(o1.getIncometax()<(o2.getIncometax())) {
			return 0;
		}
		else {
		return -1;
	}
	

}
}
