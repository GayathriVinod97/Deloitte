package Week2;

public class Division extends Arithmetic {

	public Division(int num1, int num2) {
		super(num1, num2);
		
	}

	@Override
	public double calculate(int num1,int num2) {
		if (num2==0) {
			System.out.println("second digit cannot be zero");
			return 0;
		}
		else {
		 num3= num1/num2;
		
		return num3;
		}
		
		
	}
	
	

}
