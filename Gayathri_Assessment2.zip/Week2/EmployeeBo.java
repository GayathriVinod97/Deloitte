package Week2;

public class EmployeeBo {
	public void calincomeTax (EmployeeVo employeeVo) {
		int annualIncome= employeeVo.getAnnualincome();
		double incometax= annualIncome*0.15;
		employeeVo.setIncometax(incometax);
		
	}

}
