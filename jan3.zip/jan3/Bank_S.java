package jan3;

public class Bank_S {

	public static void main(String[] args) {
		Payment_singleton payment1= Payment_singleton.getPaymentObject();
		payment1.pay(1000);
		Payment_singleton payment2= Payment_singleton.getPaymentObject();
		payment2.pay(20000);
		Payment_singleton payment3= Payment_singleton.getPaymentObject();
		payment3.pay(94444);

	}

}
