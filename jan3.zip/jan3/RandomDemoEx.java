package jan3;

public class RandomDemoEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
