package jan3;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Customermain {

	public static void main(String[] args) throws SQLException {
		Connection connection= DBConnection.makeConnection();
		Statement stmt =  connection.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,  ResultSet.CONCUR_UPDATABLE);
		ResultSet rs = stmt.executeQuery("select hr.customer.* from hr.customer");
		while (rs.next() ) {
			System.out.println( rs.getInt(1) +"      "+rs.getString(2)+"      "+rs.getString(3)+"     "+rs.getInt(4));
			}
		 rs.moveToInsertRow();
		    rs.updateInt("customerid", 300);
		   rs.updateString("customername", "Geeta");
		    rs.updateString("customeraddress", "bombay");
	     rs.updateInt("billamount", 3000);
		    rs.insertRow();
		    rs.beforeFirst();  
		    while (rs.next() ) {
		    	System.out.println( rs.getInt(1) +"      "+rs.getString(2)+"       "+rs.getString(3)+"     "+rs.getInt(4)); }
connection.close();
	}

}
