package jan3;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

public class InsertTableDemo {

	public static void main(String[] args) throws SQLException {
		Connection connection= DBConnection.makeConnection();
		Statement statement= connection.createStatement();
		String insertQuery= "insert into hr.customer values(20,'Gayathri','Kerala',15000)";
		int rowsAffected= statement.executeUpdate(insertQuery);
		System.out.println("Insert success with  "+rowsAffected);

	}

}
