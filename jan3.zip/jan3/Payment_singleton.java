package jan3;

public class Payment_singleton {
	private static Payment_singleton payment= new Payment_singleton();
	private Payment_singleton() {
		System.out.println("payment memory allocated");
	}
	public static Payment_singleton getPaymentObject() {
		return payment;
	}
	public void pay(int amount) {
		System.out.println("payment done for INR : "+amount);
	}
}
