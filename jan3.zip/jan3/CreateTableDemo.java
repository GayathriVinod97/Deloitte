package jan3;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

public class CreateTableDemo {

	public static void main(String[] args) throws SQLException {
		Connection connection= DBConnection.makeConnection();
		Statement statement= connection.createStatement();
		String query="create table hr.salarydetails(salary integer, bonus integer )";
		statement.execute(query);            //table created in sql
		System.out.println("table created");
	}

}
