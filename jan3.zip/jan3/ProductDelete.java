package jan3;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class ProductDelete {

	public static void main(String[] args) throws SQLException {
		Connection connection= DBConnection.makeConnection();
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter product id of record to be deleted");
		int pid= sc.nextInt();
	PreparedStatement statement=connection.prepareStatement("delete from hr.products where productid=?");
	statement.setInt(1, pid);
	statement.executeUpdate();
	}

}
