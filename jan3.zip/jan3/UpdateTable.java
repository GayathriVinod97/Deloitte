package jan3;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class UpdateTable {

	public static void main(String[] args) throws SQLException {
		Customer customer= new Customer();
		//customer.accept();
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter customer id to update");
		int cid= sc.nextInt();
		System.out.println("Enter new customer name");
		String name= sc.next();
		System.out.println("Enter new customer address");
		
		String address= sc.next();
		System.out.println("Enter new bill amount");
		int amount= sc.nextInt();
		
		Connection connection= DBConnection.makeConnection();
		PreparedStatement statement=connection.prepareStatement("update hr.customer set CUSTOMERNAME=name,CUSTOMERADDRESS=address,billamount= amount where customerid= cid");
	
		System.out.println(name +" , your record was saved successfully");

	}

}
