package jan3;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class ProductUpdate {

	public static void main(String[] args) throws SQLException {
		
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter product id to update");
		int pid= sc.nextInt();
		System.out.println("Enter new product name");
		String name= sc.next();
		System.out.println("Enter new product price");
		
		int price= sc.nextInt();
		System.out.println("Enter new qoh");
		int q= sc.nextInt();
		
		Connection connection= DBConnection.makeConnection();
		PreparedStatement statement=connection.prepareStatement("update hr.products set productname=?, price=?,qoh=? where productid= ?");
		statement.setInt(4, pid);
		statement.setString(1, name);
		statement.setInt(2, price);
		statement.setInt(3, q);
		statement.executeUpdate();
	statement.executeQuery();
		System.out.println(name +" , your record was saved successfully");

	}

}
