package jan3;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class JdbcDriver {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		//1.load appropriate driver
		Class.forName("oracle.jdbc.driver.OracleDriver");
		System.out.println("Driver loaded");
		
		//2.obtain database connection
		
		Connection connection= DriverManager.getConnection("jdbc:oracle:thin:@127.0.0.1:1521:xe", "system","admin");
		System.out.println("Connected");
		
		// 3.
		Statement stat= connection.createStatement();
		ResultSet res= stat.executeQuery("select * from hr.customer where billamount>2000");
		while(res.next()) {                                     // prints all contents of table..sysout(res.getString(1) prints the first entry of 1st column..put it in while loop to get all entries in that column
			System.out.print(res.getInt(1)+" ");
			System.out.print(res.getString(2)+" ");
			System.out.print(res.getString(3)+" ");
			System.out.print(res.getInt(4)+" \n");
		}
		stat.close();
		connection.close();

	}

}
