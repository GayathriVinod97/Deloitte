package jan3;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

public class ProductTable {

	public static void main(String[] args) throws SQLException {
		Connection connection= DBConnection.makeConnection();
		Statement statement= connection.createStatement();
		String query="create table hr.products(productId integer, productName varchar2(20), price integer, qoh integer )";
		statement.execute(query);            //table created in sql
		System.out.println("table created");
		

	}

}
