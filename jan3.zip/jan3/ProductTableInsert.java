package jan3;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class ProductTableInsert {

	public static void main(String[] args) throws SQLException {
		Connection connection= DBConnection.makeConnection();
		
		Scanner sc= new Scanner(System.in);
		boolean b= true;
		while(b) {
			
		
		System.out.println("Do you want to  enter product details? 1. Yes  2. No");
		int choice= sc.nextInt();
		if(choice==1) {
			System.out.println("Enter product id");
			int pid= sc.nextInt();
			System.out.println("Enter product name");
			String pname= sc.next();
			System.out.println("Enter product price");
			int pprice= sc.nextInt();
			System.out.println("Enter qoh");
			int qoh= sc.nextInt();
			
			PreparedStatement statement=connection.prepareStatement("insert into hr.products values(?,?,?,?)");
			statement.setInt(1, pid);
			
			statement.setString(2, pname);
			statement.setInt(3, pprice);
			statement.setInt(4, qoh);
			statement.executeUpdate();
			System.out.println("Record inserted");
			b=true;
			
		}
		else {
			b=false;
			
		}
		}
	}

}
