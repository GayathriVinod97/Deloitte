package jan3;

import java.io.IOException;
import java.io.RandomAccessFile;

public class RandomDemo {

	public static void main(String[] args) throws IOException {
		RandomAccessFile file= new RandomAccessFile("friday.txt", "rw");
		file.writeUTF("Today is friday");
		System.out.println(file.getFilePointer());
		long len=file.length();
		file.seek(len+1);
		file.writeUTF("Gayathri");
	//	 file.seek(0);                                    //to display from beginning
		file.seek(len+1);
		System.out.println(file.getFilePointer());
		String str = file.readLine();                             //readUTF in its actual form ..but to display entire file content use readLine 
		file.close();
	//	System.out.println("your content is : ");
	//	System.out.println(str);
		System.out.println("your name is : ");
			System.out.println(str);
		
	}

}
