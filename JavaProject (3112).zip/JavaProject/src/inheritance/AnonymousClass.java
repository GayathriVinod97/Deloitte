package inheritance;

interface ChangePassword2{
	void doChange();
}


public class AnonymousClass {
public static void main(String [] args) {
	ChangePassword2 c= new ChangePassword2() {
		
		@Override
		public void doChange() {
			// TODO Auto-generated method stub
			System.out.println("password changed");
		}
	};
	c.doChange();
}
}
