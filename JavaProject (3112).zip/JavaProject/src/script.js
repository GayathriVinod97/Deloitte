<!DOCTYPE html>
<html>
<head>
<script>
alert('hello');
</script>
<meta charset="ISO-8859-1">
<title>Insert title here</title>
</head>
<body>

</body>
</html>