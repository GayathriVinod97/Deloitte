package pack1;

public class A {
	private int i=1;

}
