package localinstancevariable;

public class casting {

	public static void main(String[] args) {
		int i=10;
		byte b=120;// not complie error 120 within range of byte.implicit casting
		float f=19.9f;//decimal values are taken as double integers as int.so cast explicit

	}

}
