package com;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import com.config.AppConfig;

public class AppSpring {

	public static void main(String[] args) {
		AbstractApplicationContext context= new AnnotationConfigApplicationContext(AppConfig.class);
		
	
		
		Customer customer1= context.getBean(Customer.class);
		Customer customer2= context.getBean(Customer.class);  //when scope is prototype default cons called twice
		customer1.setCustomerId(2001);
		customer1.setCustomerName("Jaya");
		customer1.setCustomerAddress("Jaipur");
		customer1.setBillAmount(3000);
		ContactDetails contactDetails=context.getBean(ContactDetails.class);
		contactDetails.setMobileNumber("11");
		contactDetails.setMailId("J@gmail.com");
		customer1.setContactDetails(contactDetails);
		
	
		System.out.println(customer1);
		context.registerShutdownHook();
	
		

	}

}
