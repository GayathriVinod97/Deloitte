package com.deloitte.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class HomeController {
	@RequestMapping("/Neha")
	public String gg() {
		return "ghosia";
	}
	@RequestMapping("/Customer")
	public String pp() {
		return "cust";
	}
	@RequestMapping("/Employee")
	public String ee() {
		return "emp";
	}
	@RequestMapping("/Product")
	public String dd() {
		return "prod";
	}
	@RequestMapping("/Guest")
	public String tt() {
		return "Guest";
	}
	

}
